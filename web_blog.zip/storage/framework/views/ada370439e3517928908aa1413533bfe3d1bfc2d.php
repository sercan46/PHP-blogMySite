<h1><?php echo e($title); ?></h1>
<p>This is my first Email using Laravel Application</p>
<?php /**PATH C:\xampp\htdocs\ilk\resources\views/email.blade.php ENDPATH**/ ?>