<!DOCTYPE html>
<!-- saved from url=http://www.sercanozbek.com/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="blog, blog web, sercan web, sercanozbek, blogweb, web tasarım, seo, adwords">
    <meta name="description" content="web tasarım, seo, adwords, blog. Sercan Özbek.">
    <meta name="author" content="sercan ozbek">

    <title>Sercan ÖZBEK</title>

    <!-- favicon -->
    <link rel="shortcut icon" type="image/png" href="./assests/img/favicon.png"/>

    <!--Font Awesome css-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!--Bootstrap css-->
    <link rel="stylesheet" href="./assests/css/bootstrap.css">

    <!--Owl Carousel css-->
    <link rel="stylesheet" href="./assests/css/owl.carousel.min.css">
    <link rel="stylesheet" href="./assests/css/owl.theme.default.min.css">

    <!--Magnific Popup css-->
    <link rel="stylesheet" href="./assests/css/magnific-popup.css">

    <!-- Google Fonts -->
    <link href="./assests/css/css" rel="stylesheet">

    <!--Site Main Style css-->
    <link rel="stylesheet" href="./assests/stylesheets/style.css">

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script type="text/javascript" async="" src="./assests/js/analytics.js.indir"></script><script async="" src="./assests/js/js"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-122650090-1');
    </script>

    <style type="text/css">
        .proje{
            box-shadow:4px 4px 10px grey !important;
        }
        .button {
            display: inline-block;
            padding: 15px 25px;
            font-size: 28px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            outline: none;
            color: #fff;
            background-color: darkred;
            border: none;
            border-radius: 15px;
            box-shadow: 0 9px #999;
           align-content: center;
            justify-content: center;

        }
        .button:hover {background-color: black}

        .button:active {
            background-color: #3e8e41;
            box-shadow: 0 5px #666;
            transform: translateY(6px);
        }
    </style>
</head>

<body>
<!--Preloader-->
<div class="preloader loaded">
    <div class="loader "></div>
</div>
<!--Preloader-->

<!--Navbar Start-->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <!-- LOGO -->
        <a class="navbar-brand logo" href="">
            <img src="./assests/img/logo.png" style="height: 70px;width: 90px" alt="">
        </a>

        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="navbar-collapse collapse" id="navbarCollapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="" class="nav-link active" data-scroll-nav="0" style="color: yellow;font-weight: bold">ANASAYFA</a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link" data-scroll-nav="1" style="color: yellow;font-weight: bold">HAKKIMIZDA</a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link" data-scroll-nav="2" style="color: yellow;font-weight: bold">HOBİLERİM</a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link" data-scroll-nav="3" style="color: yellow;font-weight: bold">ÇALIŞMALARIM</a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link" data-scroll-nav="5" style="color: yellow;font-weight: bold">KULLANDIĞIM PROGRAMLAMA DİLLERİ</a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link" data-scroll-nav="6" style="color: yellow;font-weight: bold">İLETİŞİM</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!--Navbar End-->

<!--Home Section Start-->
<section id="home" class="banner" style="background-image: url('./assests/img/ban.jpg'); height: 608px; background-position: 0% 0px;" data-stellar-background-ratio=".7" data-scroll-index="0">
    <div class="container">
        <!--Banner Content-->
        <div class="banner-caption">
            <p class="cd-headline clip mt-30">
                <span style="font-weight: bold">Blog Sayfama Hoşgeldiniz.</span><br>
                <span class="blc">Sizlere</span>
                <span class="cd-words-wrapper" style="width: 200px; overflow: hidden;">
                            <b class="is-visible" style="color:red">Kim olduğumdan...</b>
                            <b class="is-hidden" style="color:red">Hobilerimden...</b>
                            <b class="is-hidden" style="color:red">Çalışmalarımdan...</b>
                            <b class="is-hidden" style="color:red">Kullandığım Programlama Dillerinden...</b>
                            <b class="is-hidden" style="color:red">Bahsedeceğim.</b>
                        </span>
            </p>
        </div>
        <div class="arrow bounce">
            <a class="fa fa-chevron-down fa-2x" rel="stylesheet" href="./assests/css/fontawesome.min.css" data-scroll-nav="1"></a>
        </div>
    </div>
    <!--Creative Background Svg-->
    <svg id="home-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1400 300" style="stroke-width:4; stroke: #fff" preserveAspectRatio="none">
        <polygon class="p-curve" points="0,30 215,300 1400,-1 1400,300 0,900"></polygon>
    </svg>
</section>
<!--Home Section End-->

<!--About Section Start-->
<section class="about pt-100 pb-100" data-scroll-index="1">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <!--About Image-->
                <div class="about-img">
                    <img src="./assests/img/benkim.jpeg" style="height: 100%;width: 100%;margin-top: 50px" alt="">
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <!--About Content-->
                <div class="about-content">
                    <div class="about-heading">
                        <h2 style="color: darkred">BEN KİMİM ?</h2>
                        <span>SERCAN ÖZBEK</span>
                    </div>
                    <p>Merhabalar, ben Sercan Özbek. Memleketim Kahramanmaraş/Elbistan. 22 Yaşındayım. Düzce Üniversitesi Bilgisayar Mühendisliği bölümümden 2019 yılında mezun oldum. Ayrıca ikinci üniversite olarak Eskişehir Anadolu Üniversitesi İşletme okumaktayım. Üniversite dördüncü sınıfta  dört aylık iş yeri eğitimi için önceden iletişime geçtiğim İzmire geldim. İzmirde bir otel yazılımı yapan şirkette 4 ay işyeri eğitimi için çalıştıktan sonra 2 ayda part time olarak çalıştım. Okulumunda bitmesi ile İzmirde kalmaya karar verdim. Şuan İzmirde bir yazılım şirketinde çalışmaktayım. Gezmeyi çok seven birisiyim şuana kadar İstanbul, Balıkesir, İzmir, Düzce, Eskişehir, Ankara, Kahramanmaraş, Gaziantep şehirlerini gezdim. Yazılım programlamanın dışında vücut geliştirme sporuyla uğraşmaktayım. İleride ki hedefim bu ülkenin adına güzel hizmetler yapabilmek. </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!--About Section End-->

<!--Services Section Start-->
<section class="services bg-dark pt-100 pb-50" data-scroll-index="2">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="heading text-center">
                    <h2 style="color:white">HOBİLERİM</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <!--Service Item-->
                <div class="service-item">
                            <span class="icon"style="background-color: cornflowerblue">
                                <i class="fa fa-futbol-o" aria-hidden="true"></i>
                            </span>
                    <h4 style="color: white">Futbol Oynamak</h4>
                </div>
            </div>
            <div class="col-md-3">
                <!--Service Item-->
                <div class="service-item">
                            <span class="icon"style="background-color: darkred">
                                <i class="fa fa-volume-down" aria-hidden="true" style="color: whitesmoke" ></i>
                            </span>
                    <h4 style="color: white">Müzik Dinlemek</h4>
                </div>
            </div>
            <div class="col-md-3">
                <!--Service Item-->
                <div class="service-item">
                            <span class="icon" style="background-color: seagreen">
                                <i class="fa fa-subway" aria-hidden="true" style="color: darkred"></i>
                            </span>
                    <h4 style="color: white">Seyahate Çıkmak</h4>
                </div>
            </div>
            <div class="col-md-3">
                <!--Service Item-->
                <div class="service-item">
                            <span class="icon" style="background-color: #ffc107">
                                <i class="fa fa-flag" aria-hidden="true" style="color: black"></i>
                            </span>
                    <h4 style="color: white">Rafting Yapmak</h4>
                </div>
            </div>
            <div class="col-md-3">
                <!--Service Item-->
                <div class="service-item">
                            <span class="icon" style="background-color: black">
                                <i class="fa fa-television" aria-hidden="true" style="color: whitesmoke"></i>
                            </span>
                    <h4 style="color: white">FİLM İZLEMEK</h4>
                </div>
            </div>
            <div class="col-md-3">
                <!--Service Item-->
                <div class="service-item">
                            <span class="icon" style="background-color: greenyellow">
                                <i class="fa fa-code" aria-hidden="true" style="color: peru"></i>
                            </span>
                    <h4 style="color: white">KOD YAZMAK</h4>
                </div>
            </div>
            <div class="col-md-3">
                <!--Service Item-->
                <div class="service-item">
                            <span class="icon" style="background-color:mediumpurple">
                                <i class="fa fa-book" aria-hidden="true" style="color: #c82333"></i>
                            </span>
                    <h4 style="color: white">KİTAP OKUMAK</h4>
                </div>
            </div>
            <div class="col-md-3">
                <!--Service Item-->
                <div class="service-item">
                            <span class="icon" style="background-color: deeppink">
                                <i class="fa fa-heartbeat" aria-hidden="true" style="color: darkolivegreen"></i>
                            </span>
                    <h4 style="color: white">VÜCUT GELİŞTİRME SPORU YAPMAK</h4>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Services Section End-->

<!--Stats Section Start-->
<section class="stats pt-100 pb-100" style="background-image: url(&#39;./assests/img/d.jpg&#39;);height: 450px;padding-top: 10px">

</section>
<!--Stats Section End-->


<!--Portfolio Section Start-->
<section class="portfolio pt-100 pb-70" data-scroll-index="3">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="heading text-center">
                    <h2>ÇALIŞMALARIMDAN BAZILARI</h2>
                </div>
            </div>
        </div>
        <div class="row portfolio-items" style="position: relative; height: 1361.15px;">
            <div class="col-lg-4 col-md-6 item application" style="position: absolute; left: 0px; top: 0px;">
                <div class="item-content">
                    <img src="./assests/img/su.jpg" alt="">
                    <div class="item-overlay">
                        <h6>Dijital Su Terazisi</h6>
                        <div class="icons">
                                    <span class="icon link">
                                        <a href="./assests/img/su.jpg">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 item application" style="position: absolute; left: 379px; top: 0px;">
                <div class="item-content">
                    <img src="./assests/img/der.jpg" alt="">
                    <div class="item-overlay">
                        <h6>DERNEK TAKİP OTOMASYONU</h6>
                        <div class="icons">
                                    <span class="icon link">
                                        <a href="./assests/img/der.jpg">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 item application" style="position: absolute; left: 759px; top: 0px;">
                <div class="item-content">
                    <img src="./assests/img/has.jpg" alt="">
                    <div class="item-overlay">
                        <h6>HASTANE OTOMASYONU</h6>
                        <div class="icons">
                                    <span class="icon link">
                                        <a href="./assests/img/has.jpg">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 item application" style="position: absolute; left: 0px; top: 226px;">
                <div class="item-content">
                    <img src="./assests/img/turn.jpg" alt="">
                    <div class="item-overlay">
                        <h6>TURNİKE TAKİP</h6>
                        <div class="icons">
                                    <span class="icon link">
                                        <a href="./assests/img/turn.jpg">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 item application" style="position: absolute; left: 379px; top: 226px;">
                <div class="item-content">
                    <img src="./assests/img/web.jpg" alt="">
                    <div class="item-overlay">
                        <h6>WEB SİTE TASARIM</h6>
                        <div class="icons">
                                    <span class="icon link">
                                        <a href="./assests/img/web.jpg">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 item application" style="position: absolute; left: 759px; top: 226px;">
                <div class="item-content">
                    <img src="./assests/img/otel.jpg" alt="">
                    <div class="item-overlay">
                        <h6>OTEL MOBİL UYGULAMA</h6>
                        <div class="icons">
                                    <span class="icon link">
                                        <a href="./assests/img/der.jpg">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="portfolio pt-100 pb-70" data-scroll-index="5" style="background-color: lightgray">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="heading text-center">
                    <h2>RESİM GALERİM</h2>
                </div>
            </div>
        </div>
        <div class="row portfolio-items" style="position: relative; height: 1361.15px;">
            <div class="col-lg-4 col-md-6 item application" style="position: absolute; left: 0px; top: 0px;">
                <div class="item-content">
                    <img src="./assests/img/1.jpg" alt="">
                    <div class="item-overlay">
                        <h6>Sinema Çıkışı :)</h6>
                        <div class="icons">
                                    <span class="icon link">
                                        <a href="./assests/img/1.jpg">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 item application" style="position: absolute; left: 379px; top: 0px;">
                <div class="item-content">
                    <img src="./assests/img/2.jpg" alt="">
                    <div class="item-overlay">
                        <h6>Yağmurlu bir sabah :)</h6>
                        <div class="icons">
                                    <span class="icon link">
                                        <a href="./assests/img/2.jpg">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 item application" style="position: absolute; left: 759px; top: 0px;">
                <div class="item-content">
                    <img src="./assests/img/3.jpg" alt="">
                    <div class="item-overlay">
                        <h6>Spor Sonrası :)</h6>
                        <div class="icons">
                                    <span class="icon link">
                                        <a href="./assests/img/3.jpg">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 item application" style="position: absolute; left: 0px; top: 226px;">
                <div class="item-content">
                    <img src="./assests/img/4.jpg" alt="">
                    <div class="item-overlay">
                        <h6>Alışveriş sonrası :)</h6>
                        <div class="icons">
                                    <span class="icon link">
                                        <a href="./assests/img/4.jpg">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 item application" style="position: absolute; left: 379px; top: 226px;">
                <div class="item-content">
                    <img src="./assests/img/5.jpg" alt="">
                    <div class="item-overlay">
                        <h6>Sahilde Şarap Keyfi :)</h6>
                        <div class="icons">
                                    <span class="icon link">
                                        <a href="./assests/img/5.jpg">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Contact Section Start-->
<section class="contact pt-100 pb-100" data-scroll-index="6" style="background-color:#f2f2f2">
    <div class="container">
        <div class="row">
            <div class="col text-center">
                <div class="heading">

                    <img src="./assests/img/ml.gif" alt="" style="width: 300px;height: 250px">

                    <h2>BANA YAZABİLİRSİN :)</h2>
                </div>
            </div>
        </div>
        <div class="row">
                <!--Contact Form-->
            <div class="col text-center">
                <a href="<?php echo e(url('/contact')); ?>">
                    <button class="button" href="<?php echo e(url('/contact')); ?>">Mail Göndermek İçin Tıklayınız!</button>
                </a>
            </div>
        </div>

    </div>
</section>
<!--Contact Section End-->

<!--Footer Start-->
<footer class="pt-50 pb-50" style="background-color:cadetblue ">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-4 col-sm-6">
                <!--Contant Item-->
                <div class="contact-info">
                    <h5 style="color: darkred">Telefon</h5>
                    <p><a href="tel:+90536704868" target="_blank">+90 (536) 708 47 68</a></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <!--Contant Item-->
                <div class="contact-info">
                    <h5 style="color:darkred;">Eposta</h5>
                    <p><a href="mailto:chesercan@gmail.com" target="_blank">chesercan@gmail.com</a></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <!--Contant Item-->
                <div class="contact-info">
                    <h5 style="color:darkred;">Adres</h5>
                    <p><a href="https://www.google.com.tr/maps/place/38%C2%B027'56.7%22N+27%C2%B013'14.7%22E/@38.465738,27.2202078,19z/data=!3m1!4b1!4m6!3m5!1s0x0:0x0!7e2!8m2!3d38.4657366!4d27.2207548" target="_blank">Erzene Mahallesi Kazım Karabekir Caddesi No:23 Mevlüt Usta Apartmanı Bornova/İZMİR.</a></p>
                </div>
            </div>
        </div>
        <div class="row text-center">
            <div class="col-md-12">
                <img src="./assests/img/at.gif" alt="" style="width: 180px;height: 90px">

                <hr>
                <a  style="color:darkred;padding-right: 20px" href="https://www.instagram.com/sercanozbek/">
                <i class="fa fa-instagram fa-lg"></i>
                </a>
                <a  style="color:darkred;padding-right: 20px" href="https://tr.linkedin.com/in/sercan-özbek-548163151?trk=people-guest_profile-result-card_result-card_full-click">
                <i class="fa fa-linkedin fa-lg" style="color:darkblue;padding-left: 20px"></i>
                </a>
                <p class="copy pt-30"  style="font-weight: bold;color: black">

                    Sercan ÖZBEK © 2019.
                </p>
            </div>
        </div>
    </div>
</footer>
<!--Footer End-->

<!--Jquery js-->
<script src="./assests/js/jquery-3.0.0.min.js.indir"></script>
<!--Bootstrap js-->
<script src="./assests/js/bootstrap.min.js.indir"></script>
<!--Stellar js-->
<script src="./assests/js/jquery.stellar.js.indir"></script>
<!--Animated Headline js-->
<script src="./assests/js/animated.headline.js.indir"></script>
<!--Owl Carousel js-->
<script src="./assests/js/owl.carousel.min.js.indir"></script>
<!--ScrollIt js-->
<script src="./assests/js/scrollIt.min.js.indir"></script>
<!--Isotope js-->
<script src="./assests/js/isotope.pkgd.min.js.indir"></script>
<!--Magnific Popup js-->
<script src="./assests/js/jquery.magnific-popup.min.js.indir"></script>
<!--Site Main js-->
<script src="./assests/js/main.js.indir"></script>




</body></html>
<?php /**PATH C:\xampp\htdocs\ilk\resources\views/welcome.blade.php ENDPATH**/ ?>