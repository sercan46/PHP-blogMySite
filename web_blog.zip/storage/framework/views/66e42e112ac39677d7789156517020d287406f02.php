<div>
    Hi, This is : <?php echo e($name); ?>

</div>
<?php /**PATH C:\xampp\htdocs\ilk\resources\views/name.blade.php ENDPATH**/ ?>