<html>
<head></head>
<body>
<p><strong>Ad Soyad:</strong> <?php echo e($name); ?></p>
<p><strong>Eposta:</strong> <?php echo e($email); ?></p>
<p><strong>Telefon:</strong> <?php echo e($phone); ?></p>
<p><strong>Mesaj:</strong> <?php echo e($messagetext); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ilk\resources\views/contacttext.blade.php ENDPATH**/ ?>