<?php echo e($data['name']); ?>


Laravel sending email made simple

<?php echo e($data['message']); ?>

<?php /**PATH C:\xampp\htdocs\ilk\resources\views/emails/plain.blade.php ENDPATH**/ ?>