<p>Hi, This is <?php echo e($data['name']); ?></p>
<p>I have some query like <?php echo e($data['message']); ?>.</p>
<p>It would be appriciative, if you gone through this feedback.</p>
<?php /**PATH C:\xampp\htdocs\ilk\resources\views/dynamic_email_template.blade.php ENDPATH**/ ?>