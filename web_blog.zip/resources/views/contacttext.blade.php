<html>
<head></head>
<body>
<p><strong>Ad Soyad:</strong> {{ $name }}</p>
<p><strong>Eposta:</strong> {{ $email }}</p>
<p><strong>Telefon:</strong> {{ $phone }}</p>
<p><strong>Mesaj:</strong> {{ $messagetext }}</p>
</body>
</html>
